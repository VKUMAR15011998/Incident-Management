sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("ns001.incidents001.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map